import React, { useState } from 'react';
import ServicioUsuario from '../servicios/ServicioUsuario';

const Administrador= ({usuario}) =>{

 
return(
    <>
    <p>hola {usuario}</p>
    </>
)
};
export default Administrador;